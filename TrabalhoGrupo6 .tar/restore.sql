--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4
-- Dumped by pg_dump version 15.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE academia;
--
-- Name: academia; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE academia WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE academia OWNER TO postgres;

\connect academia

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: instrutor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.instrutor (
    idinstrutor integer NOT NULL,
    rg bigint,
    nome character varying(255)
);


ALTER TABLE public.instrutor OWNER TO postgres;

--
-- Name: instrutor_idinstrutor_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.instrutor_idinstrutor_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.instrutor_idinstrutor_seq OWNER TO postgres;

--
-- Name: instrutor_idinstrutor_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.instrutor_idinstrutor_seq OWNED BY public.instrutor.idinstrutor;


--
-- Name: telefone; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.telefone (
    id integer NOT NULL,
    idinstrutor integer,
    numero bigint
);


ALTER TABLE public.telefone OWNER TO postgres;

--
-- Name: telefone_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.telefone_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.telefone_id_seq OWNER TO postgres;

--
-- Name: telefone_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.telefone_id_seq OWNED BY public.telefone.id;


--
-- Name: turma; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.turma (
    idinstrutor integer,
    idturma integer NOT NULL,
    nome_disciplina character varying(255),
    dia_semana character varying(255)
);


ALTER TABLE public.turma OWNER TO postgres;

--
-- Name: turma_idturma_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.turma_idturma_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.turma_idturma_seq OWNER TO postgres;

--
-- Name: turma_idturma_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.turma_idturma_seq OWNED BY public.turma.idturma;


--
-- Name: instrutor idinstrutor; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instrutor ALTER COLUMN idinstrutor SET DEFAULT nextval('public.instrutor_idinstrutor_seq'::regclass);


--
-- Name: telefone id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telefone ALTER COLUMN id SET DEFAULT nextval('public.telefone_id_seq'::regclass);


--
-- Name: turma idturma; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.turma ALTER COLUMN idturma SET DEFAULT nextval('public.turma_idturma_seq'::regclass);


--
-- Data for Name: instrutor; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3339.dat

--
-- Data for Name: telefone; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3341.dat

--
-- Data for Name: turma; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3343.dat

--
-- Name: instrutor_idinstrutor_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.instrutor_idinstrutor_seq', 12, true);


--
-- Name: telefone_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.telefone_id_seq', 25, true);


--
-- Name: turma_idturma_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.turma_idturma_seq', 2, true);


--
-- Name: instrutor instrutor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instrutor
    ADD CONSTRAINT instrutor_pkey PRIMARY KEY (idinstrutor);


--
-- Name: telefone telefone_idinstrutor_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telefone
    ADD CONSTRAINT telefone_idinstrutor_key UNIQUE (idinstrutor);


--
-- Name: telefone telefone_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telefone
    ADD CONSTRAINT telefone_pkey PRIMARY KEY (id);


--
-- Name: turma turma_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.turma
    ADD CONSTRAINT turma_pkey PRIMARY KEY (idturma);


--
-- Name: turma fkq0s0wd3vvm952eke1c40df8dj; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.turma
    ADD CONSTRAINT fkq0s0wd3vvm952eke1c40df8dj FOREIGN KEY (idinstrutor) REFERENCES public.instrutor(idinstrutor);


--
-- Name: telefone fkqbvtq7gqdgxlavp087c7vbuq; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telefone
    ADD CONSTRAINT fkqbvtq7gqdgxlavp087c7vbuq FOREIGN KEY (idinstrutor) REFERENCES public.instrutor(idinstrutor);


--
-- PostgreSQL database dump complete
--

